package org.mifos.mobile.models.notification

/**
 * Created by dilpreet on 26/09/17.
 */

data class NotificationRegisterPayload(
        var clientId: Long,
        var registrationId: String)
