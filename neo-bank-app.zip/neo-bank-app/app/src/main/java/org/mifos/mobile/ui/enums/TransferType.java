package org.mifos.mobile.ui.enums;

/**
 * Created by dilpreet on 6/7/17.
 */

public enum TransferType {
    TPT,
    SELF
}
