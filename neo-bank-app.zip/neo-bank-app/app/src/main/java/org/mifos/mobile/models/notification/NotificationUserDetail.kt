package org.mifos.mobile.models.notification

import com.google.gson.annotations.SerializedName

/**
 * Created by dilpreet on 17/12/17.
 */

data class NotificationUserDetail (

    @SerializedName("id") var id: Int = 0
)
