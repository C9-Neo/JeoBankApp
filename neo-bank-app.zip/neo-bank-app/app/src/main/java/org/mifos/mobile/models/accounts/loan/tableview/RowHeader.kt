package org.mifos.mobile.models.accounts.loan.tableview

data class RowHeader(val data: Any)