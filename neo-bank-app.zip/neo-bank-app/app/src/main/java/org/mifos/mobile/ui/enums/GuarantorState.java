package org.mifos.mobile.ui.enums;

/*
 * Created by saksham on 25/July/2018
 */

public enum GuarantorState {
    CREATE,
    UPDATE
}
