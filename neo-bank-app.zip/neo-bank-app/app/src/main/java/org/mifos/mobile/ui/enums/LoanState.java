package org.mifos.mobile.ui.enums;

/**
 * Created by dilpreet on 3/6/17.
 */

public enum LoanState {
    CREATE,
    UPDATE
}
