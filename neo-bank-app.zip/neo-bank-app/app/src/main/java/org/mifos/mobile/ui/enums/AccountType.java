package org.mifos.mobile.ui.enums;

/**
 * @author Rajan Maurya
 *         On 24/03/17.
 */

public enum AccountType {

    SAVINGS,

    LOAN,

    SHARE

}
