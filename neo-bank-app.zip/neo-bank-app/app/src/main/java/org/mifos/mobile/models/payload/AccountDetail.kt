package org.mifos.mobile.models.payload

/**
 * Created by dilpreet on 19/03/18.
 */

data class AccountDetail(
        var accountNumber: String,
        var accountType: String)
