package org.mifos.mobile.utils;

/**
 * Created by dilpreet on 6/3/17.
 */

public enum DatePick {
    START ,
    END
}
