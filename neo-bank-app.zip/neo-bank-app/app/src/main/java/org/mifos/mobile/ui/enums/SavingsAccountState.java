package org.mifos.mobile.ui.enums;

/*
 * Created by saksham on 02/July/2018
 */

public enum SavingsAccountState {
    CREATE,
    UPDATE
}
