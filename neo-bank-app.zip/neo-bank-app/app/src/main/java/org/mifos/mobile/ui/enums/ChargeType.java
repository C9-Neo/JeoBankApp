package org.mifos.mobile.ui.enums;

/**
 * Created by dilpreet on 19/7/17.
 */

public enum ChargeType {
    CLIENT,
    SAVINGS,
    LOAN
}
