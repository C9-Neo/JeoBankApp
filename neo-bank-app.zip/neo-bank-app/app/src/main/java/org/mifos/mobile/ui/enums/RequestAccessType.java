package org.mifos.mobile.ui.enums;

/**
 * Created by manishkumar on 19/05/18.
 */

public enum RequestAccessType {
    CAMERA,
    EXTERNAL_STORAGE_READ,
    EXTERNAL_STORAGE_WRITE
}
