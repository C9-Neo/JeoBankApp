package org.mifos.mobile.models.accounts.loan.tableview

data class Cell(val data: Any)
