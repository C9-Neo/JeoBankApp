package org.mifos.mobile.ui.enums;

/**
 * Created by dilpreet on 16/6/17.
 */

public enum BeneficiaryState {
    CREATE_MANUAL,
    CREATE_QR,
    UPDATE
}
