package org.mifos.mobile.utils;

/**
 * Created by Rajan Maurya on 05/03/17.
 */

public class SymbolsUtils {

    public static final String PERCENT = "%";
}
