package org.mifos.mobile.models.accounts.loan.tableview

data class ColumnHeader(val data : Any)