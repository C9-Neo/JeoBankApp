package com.drawingtest.ui.activity;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import com.drawingtest.ui.component.PixelGridView;

public class ShowGrid extends AppCompatActivity {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        PixelGridView pixelGrid = new PixelGridView(this);
        pixelGrid.setNumColumns(3);
        pixelGrid.setNumRows(3);

        setContentView(pixelGrid);
    }
}
