package net.mskurt.albumlist2;

import android.app.Activity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {

    private RecyclerView recyclerView;
    private RecyclerViewAdapter adapter;
    private RecyclerView.LayoutManager layoutManager;
    private List<Album> albumList;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Create model list
        albumList=new ArrayList<>();
        albumList.add(new Album("Pies Descalzos","eminem",R.drawable.eminem));
        albumList.add(new Album("Laundry Service","eminem",R.drawable.eminem));
        albumList.add(new Album("She Wolf", "eminem", R.drawable.eminem));
        albumList.add(new Album("Sale el Sol", "eminem", R.drawable.eminem));
        albumList.add(new Album("MTV Unplugged","eminem",R.drawable.eminem));
        albumList.add(new Album("Live & Off the Record","eminem",R.drawable.eminem));

        albumList.add(new Album("michael","michael",R.drawable.michael));
        albumList.add(new Album("Vivir","michael",R.drawable.michael));
        albumList.add(new Album("Cosas del Amor","michael",R.drawable.michael));
        albumList.add(new Album("Enrique","michael",R.drawable.michael));
        albumList.add(new Album("Escape","michael",R.drawable.michael));
        albumList.add(new Album("Sex and Love","michael",R.drawable.michael));


        albumList.add(new Album("M.I.A.M.I.","lee",R.drawable.lee));
        albumList.add(new Album("El Mariel","lee",R.drawable.lee));
        albumList.add(new Album("The Boatlift","lee",R.drawable.lee));
        albumList.add(new Album("lee Starring in Rebelution","lee",R.drawable.lee));
        albumList.add(new Album("Armando","lee",R.drawable.lee));
        albumList.add(new Album("Planet Pit","lee",R.drawable.lee));
        albumList.add(new Album("Global Warming","lee",R.drawable.lee));

        albumList.add(new Album("Dangerously in Love","shakira",R.drawable.shakira));
        albumList.add(new Album("B'Day","shakira",R.drawable.shakira));
        albumList.add(new Album("I Am... Sasha Fierce","shakira",R.drawable.shakira));
        albumList.add(new Album("Beyoncé","shakira",R.drawable.shakira));
        albumList.add(new Album("Live at Wembley","shakira",R.drawable.shakira));
        albumList.add(new Album("I Am... World Tour","shakira",R.drawable.shakira));


        recyclerView = (RecyclerView) findViewById(R.id.recycler_view);


        layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);


        adapter = new RecyclerViewAdapter(MainActivity.this,albumList);
        recyclerView.setAdapter(adapter);
    }

}
