package net.mskurt.albumlist2;

import android.content.Context;
import android.os.Build;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

public class RecyclerViewAdapter extends RecyclerView.Adapter<RecyclerViewAdapter.ViewHolder> {

    private Context context;
    private List<Album> albumList;
    private LayoutInflater inflater;



    public class ViewHolder extends RecyclerView.ViewHolder {
        public TextView albumName;
        public TextView artistName;
        public ImageView albumCoverImage;
        public ViewHolder(View v) {
            super(v);
            albumName=(TextView)v.findViewById(R.id.album_name);
            artistName=(TextView)v.findViewById(R.id.artist_name);
            albumCoverImage=(ImageView)v.findViewById(R.id.album_cover);
        }
    }



    public RecyclerViewAdapter(Context context,List<Album> albumList) {
        this.context=context;
        this.albumList=albumList;
        inflater=(LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }



    @Override
    public RecyclerViewAdapter.ViewHolder onCreateViewHolder(ViewGroup parent,int viewType) {
        View v = inflater.inflate(R.layout.album_card, parent, false);
        return new ViewHolder(v);
    }



    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        holder.albumName.setText(albumList.get(position).getAlbumName());
        holder.artistName.setText(albumList.get(position).getArtistName());
        setImageViewBackgroundWithADrawable(holder.albumCoverImage, albumList.get(position).getAlbumCoverDrawableId());
    }

    @Override
    public int getItemCount() {
        return albumList.size();
    }


    public void setImageViewBackgroundWithADrawable(ImageView image,int drawable){
        if(Build.VERSION.SDK_INT >=22){
            image.setBackground(context.getResources().getDrawable(drawable, null));
        }
        else if(Build.VERSION.SDK_INT >= 16){
            image.setBackground(context.getResources().getDrawable(drawable));
        }else{
            image.setBackgroundDrawable(context.getResources().getDrawable(drawable));
        }
    }
}