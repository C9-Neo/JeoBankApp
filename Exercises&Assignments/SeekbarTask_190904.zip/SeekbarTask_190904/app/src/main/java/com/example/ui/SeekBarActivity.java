package com.example.ui;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ListView;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;
import android.widget.Toast;
import android.widget.Spinner;
import android.widget.Button;
import android.widget.ArrayAdapter;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import java.util.ArrayList;
import java.util.List;
import android.view.View;
import android.view.View.OnClickListener;

public class SeekBarActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_seekbar);

        final SeekBar volumeControl = (SeekBar) findViewById(R.id.VolumeControl);

        volumeControl.setProgress(4);
        volumeControl.setMax(14);

        volumeControl.setOnSeekBarChangeListener(new OnSeekBarChangeListener() {
            int progressChanged = 0;

            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                progressChanged = progress + 1;
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                Toast.makeText(SeekBarActivity.this, "seek bar progress: " + progressChanged, Toast.LENGTH_SHORT)
                        .show();
            }
        });

        final Spinner spinControl = (Spinner) findViewById(R.id.SpinControl);
        final Button spinSubmit = (Button) findViewById(R.id.SpinSubmit);

        List<String> rows = new ArrayList<String>();
        rows.add("Row-1");
        rows.add("Row-2");
        rows.add("Row-3");
        rows.add("Row-4");
        rows.add("Row-5");
        rows.add("Row-6");

        ArrayAdapter<String> daRow = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, rows);
        daRow.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinControl.setAdapter(daRow);

        spinSubmit.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(SeekBarActivity.this, "Chose: "+ String.valueOf(spinControl.getSelectedItem()), Toast.LENGTH_SHORT).show();
            }
        });

        final ListView LVControl = (ListView) findViewById(R.id.LVControl);

        List<String> cols = new ArrayList<String>();
        cols.add("Col-1");
        cols.add("Col-2");
        cols.add("Col-3");
        cols.add("Col-4");
        cols.add("Col-5");
        cols.add("Col-6");

        final ArrayAdapter<String> daCol = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, cols);
        daCol.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        LVControl.setAdapter(daCol);

        LVControl.setOnItemClickListener(new OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Toast.makeText(SeekBarActivity.this, "Chose: " + String.valueOf(daCol.getItem(position)), Toast.LENGTH_SHORT).show();
            }
        });
    }
}
